import os

def read_file(path):

    if not os.path.exists(path):
        return "الملف غير موجود"

    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()[:3000]
    except:
        return "لا يمكن قراءة الملف"