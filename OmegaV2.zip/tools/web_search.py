import requests


def search_web(query):
    url = "https://duckduckgo.com/html/"

    params = {
        "q": query
    }

    res = requests.post(url, data=params)

    return res.text[:2000]  # نرجع جزء بسيط