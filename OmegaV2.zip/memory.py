# memory.py - نظام الذاكرة المحسّن لمنع الهلوسة ودعم الملخصات
from typing import List, Dict, Optional, Callable
from collections import deque
import json
import re
from datetime import datetime


def estimate_tokens(text: str) -> int:
    """
    تقدير عدد الرموز بدقة أعلى قليلاً.
    """
    if not text:
        return 0
    # حساب تقريبي: كلمات + أحرف/4
    return max(1, len(text.split()) + len(text) // 5)


class Memory:
    """
    نظام الذاكرة القصيرة المدى للمحادثة مع دعم الملخصات لمنع فقدان السياق.
    """

    def __init__(
            self,
            max_history: int = 50,
            max_tokens: Optional[int] = 2000,
            token_counter: Optional[Callable[[str], int]] = None,
            summary_ratio: float = 0.2  # نسبة الذاكرة المخصصة للملخص عند الامتلاء
    ):
        """
        Args:
            max_history: أقصى عدد رسائل.
            max_tokens: أقصى عدد رموز.
            token_counter: دالة عد الرموز.
            summary_ratio: النسبة المئوية للمساحة المخصصة للملخص عند الضغط (مثلاً 20%).
        """
        self.max_history = max_history
        self.max_tokens = max_tokens
        self.token_counter = token_counter or estimate_tokens
        self.summary_ratio = summary_ratio

        # تخزين الرسائل
        self.messages: deque = deque(maxlen=max_history)
        self.total_tokens = 0

        # حقل خاص لتخزين ملخص المحادثة القديمة
        self._conversation_summary = ""

    def add(self, role: str, content: str) -> bool:
        """إضافة رسالة جديدة مع إدارة ذكية للذاكرة"""
        if role not in ("user", "assistant", "system"):
            raise ValueError(f"❌ دور غير معروف: {role}")

        content = content.strip()
        if not content:
            return False

        # تنظيف النص من تكرار الأسطر والرموز الغريبة التي تسبب هلوسة
        content = self._clean_content(content)

        token_count = self.token_counter(content)

        # إذا كانت الرسالة الجديدة وحدها تتجاوز الحد، نحذر لكن نضيفها (مهم جداً)
        if self.max_tokens and token_count > self.max_tokens:
            # نفرغ الذاكرة تقريباً لنترك مكاناً لهذه الرسالة الضخمة
            self.clear()
            self.total_tokens = 0

        # إدارة الامتلاء: إذا تجاوزنا الحد، نحذف الأقدم أو ننشئ ملخصاً
        if self.max_tokens and (self.total_tokens + token_count) > self.max_tokens:
            self._manage_overflow(token_count)

        message = {
            "role": role,
            "content": content,
            "tokens": token_count,
            "timestamp": datetime.now().isoformat()
        }
        self.messages.append(message)
        self.total_tokens += token_count

        return True

    def _clean_content(self, text: str) -> str:
        """تنظيف النص لتقليل الضوضاء المسببة للهلوسة"""
        # إزالة المسافات الزائدة
        text = re.sub(r'\s+', ' ', text)
        # إزالة الأسطر الفارغة المتكررة
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text.strip()

    def _manage_overflow(self, new_token_count: int):
        """
        إدارة امتلاء الذاكرة بذكاء:
        1. محاولة إنشاء ملخص إذا لم يوجد.
        2. حذف الرسائل الأقدم مع الحفاظ على الملخص.
        """
        target_limit = int(self.max_tokens * (1 - self.summary_ratio)) if self.max_tokens else self.max_tokens

        # نحذف حتى نصل للحد الآمن
        while len(self.messages) > 1 and self.total_tokens > target_limit:
            old_msg = self.messages.popleft()
            self.total_tokens -= old_msg.get("tokens", 0)

            # هنا يمكن مستقبلاً إضافة منطق لاستخراج الحقائق من الرسالة المحذوفة وإضافتها للملخص
            # حالياً نقوم بالحذف البسيط لتفادي التعقيد، لكن الهيكل جاهز للتطوير

    def set_summary(self, summary_text: str):
        """تعيين ملخص يدوي للمحادثة السابقة (يُستخدم في الـ Prompt)"""
        self._conversation_summary = summary_text

    def get_summary(self) -> str:
        return self._conversation_summary

    def add_user(self, content: str) -> bool:
        return self.add("user", content)

    def add_assistant(self, content: str) -> bool:
        return self.add("assistant", content)

    def add_system(self, content: str) -> bool:
        return self.add("system", content)

    def get(self) -> List[Dict]:
        return list(self.messages)

    def get_last_n(self, n: int) -> List[Dict]:
        if n <= 0:
            return []
        return list(self.messages)[-n:]

    def clear(self) -> None:
        self.messages.clear()
        self.total_tokens = 0
        self._conversation_summary = ""

    def get_stats(self) -> Dict:
        total_messages = len(self.messages)
        user_messages = sum(1 for m in self.messages if m["role"] == "user")
        assistant_messages = sum(1 for m in self.messages if m["role"] == "assistant")

        usage_percent = (self.total_tokens / self.max_tokens * 100) if self.max_tokens else 0

        return {
            "total_messages": total_messages,
            "user_messages": user_messages,
            "assistant_messages": assistant_messages,
            "total_tokens": self.total_tokens,
            "max_tokens": self.max_tokens,
            "memory_usage_percent": usage_percent,
            "has_summary": bool(self._conversation_summary)
        }

    def format_as_prompt(
            self,
            system_prompt: Optional[str] = None,
            template: str = "simple",
            max_messages: Optional[int] = None,
            include_timestamps: bool = False
    ) -> str:
        """
        تحويل الذاكرة إلى نص جاهز للنموذج مع دعم الملخصات والفواصل الواضحة.
        """
        messages_to_use = list(self.messages)

        if max_messages and max_messages > 0:
            messages_to_use = messages_to_use[-max_messages:]

        lines = []

        # 1. إضافة System Prompt (أساسي لمنع الهلوسة)
        if system_prompt:
            lines.append(f"<|system|>\n{system_prompt}\n<|end|>")

        # 2. إضافة الملخص إذا وجد (يساعد النموذج على تذكر الماضي البعيد)
        if self._conversation_summary:
            if template == "simple":
                lines.append(f"\n<|summary|>\nملخص لما سبق: {self._conversation_summary}\n<|end|>")
            elif template == "qa":
                lines.append(f"\nملخص السابق: {self._conversation_summary}")

        lines.append("")  # فاصل

        # 3. إضافة الرسائل الحالية
        for i, msg in enumerate(messages_to_use):
            role = msg["role"]
            content = msg["content"]

            # تنسيق مختلف حسب القالب لضمان وضوح الأدوار
            if template == "simple":
                role_name = "مستخدم" if role == "user" else "مساعد"
                lines.append(f"{role_name}: {content}")

            elif template == "qa":
                label = "السؤال" if role == "user" else "الإجابة"
                lines.append(f"{label}: {content}")

            elif template == "llama":
                if role == "user":
                    lines.append(f"[INST] {content} [/INST]")
                elif role == "assistant":
                    lines.append(f"{content}")

            elif template == "chatml":
                lines.append(f"<|{role}|>\n{content}<|end|>")

        # إضافة مؤشر الرد التالي
        if template == "simple":
            lines.append("مساعد: ")
        elif template == "qa":
            lines.append("الإجابة: ")
        elif template == "llama":
            pass  # النموذج يكمل تلقائياً
        elif template == "chatml":
            lines.append("<|assistant|>\n")

        return "\n".join(lines)

    def export_to_json(self, filepath: str) -> bool:
        try:
            data = {
                "messages": list(self.messages),
                "summary": self._conversation_summary,
                "stats": self.get_stats()
            }
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"❌ خطأ في الحفظ: {e}")
            return False

    def import_from_json(self, filepath: str) -> bool:
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)

            self.clear()

            # تحميل الملخص أولاً
            if "summary" in data:
                self._conversation_summary = data["summary"]

            # تحميل الرسائل
            msgs = data.get("messages", [])
            for msg in msgs:
                if "role" in msg and "content" in msg:
                    self.add(msg["role"], msg["content"])

            return True
        except Exception as e:
            print(f"❌ خطأ في التحميل: {e}")
            return False

    def __len__(self) -> int:
        return len(self.messages)

    def __repr__(self) -> str:
        return f"Memory(msgs={len(self.messages)}, tokens={self.total_tokens}, summary={bool(self._conversation_summary)})"